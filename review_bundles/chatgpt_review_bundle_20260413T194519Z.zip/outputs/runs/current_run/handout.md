﻿# Country Destabilization Prototype V4.3.2 - Handout

## Run-Zusammenfassung

- Run timestamp: 2026-04-13T19:44:45.975927+00:00
- Countries: Germany, Israel, Iran, Ukraine, Russia, Japan, China, Taiwan, Poland, Nigeria
- Proposed run status: erfolgreich
- Effective run status: erfolgreich
- Status override active: nein
- Vergleich letzter Run: ok
- Vergleich Referenz-Run: ok (already_exists)

## Versionsstände

- Query version: v1
- Scoring version: v4.3
- Bridge file version: v1
- Context table version: v1

## Vergleich zum letzten Run (gesamt)

- Items: 30
- Zunehmend: 0
- Rückläufig: 0
- Stabil: 30
- Kein Vergleich: 0

## V4.3 Comparative Expansion: 10 Countries, Full 356-Day Profiles

- Fokus: verlaufsgetriebener 356-Tage-Laendervergleich (nicht primaer episodengetrieben).
- Hauptvergleichstabelle:

- Iran: current=54.39, confidence=91.90 (hoch), freshness=fresh_operational, year_max=78.37, year_min=53.99, volatility=9.18, range=24.38, dominant=event, support=broad.
- Ukraine: current=53.08, confidence=91.82 (hoch), freshness=fresh_operational, year_max=79.51, year_min=52.33, volatility=9.10, range=27.18, dominant=event, support=broad.
- Nigeria: current=50.12, confidence=91.76 (hoch), freshness=fresh_operational, year_max=78.48, year_min=50.12, volatility=10.04, range=28.36, dominant=event, support=broad.
- Russia: current=49.13, confidence=91.74 (hoch), freshness=fresh_operational, year_max=74.24, year_min=48.13, volatility=9.01, range=26.11, dominant=event, support=broad.
- Taiwan: current=41.59, confidence=91.81 (hoch), freshness=fresh_operational, year_max=61.96, year_min=38.11, volatility=8.60, range=23.85, dominant=event, support=narrow.
- Israel: current=40.02, confidence=91.50 (hoch), freshness=fresh_operational, year_max=70.45, year_min=40.02, volatility=10.03, range=30.43, dominant=event, support=narrow.
- China: current=36.38, confidence=91.59 (hoch), freshness=fresh_operational, year_max=65.42, year_min=35.95, volatility=8.47, range=29.47, dominant=event, support=narrow.
- Poland: current=29.38, confidence=91.44 (hoch), freshness=fresh_operational, year_max=54.86, year_min=29.38, volatility=7.42, range=25.48, dominant=event, support=narrow.
- Germany: current=23.18, confidence=91.39 (hoch), freshness=fresh_operational, year_max=47.74, year_min=23.18, volatility=8.52, range=24.56, dominant=market_food, support=narrow.
- Japan: current=17.72, confidence=91.34 (hoch), freshness=fresh_operational, year_max=38.73, year_min=17.72, volatility=6.97, range=21.01, dominant=narrative, support=narrow.

## V4.3 Vertiefende Diagnostik

- Top-Peak je Land:
- Ukraine / 2026-02: 79.51 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- Iran / 2025-08: 77.97 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- Nigeria / 2025-07: 75.60 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- Russia / 2026-02: 74.24 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- Israel / 2025-12: 70.28 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- China / 2026-02: 65.42 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- Taiwan / 2025-08: 61.92 (hoch), driver=market_food, fresh_share=0.81, stale_share=0.00.
- Poland / 2026-02: 54.86 (erhoeht), driver=market_food, fresh_share=0.79, stale_share=0.00.
- Germany / 2025-12: 47.74 (erhoeht), driver=market_food, fresh_share=0.84, stale_share=0.00.
- Japan / 2025-12: 37.56 (erhoeht), driver=market_food, fresh_share=0.83, stale_share=0.00.

- Mittlerer dominanter Gruppenbeitrag (356 Tage):
- Germany: market_food (mean_score=51.02, mean_share=0.26, active_ratio=0.42).
- Israel: event (mean_score=60.12, mean_share=0.18, active_ratio=0.83).
- Iran: event (mean_score=76.75, mean_share=0.18, active_ratio=1.00).
- Ukraine: event (mean_score=73.17, mean_share=0.18, active_ratio=1.00).
- Russia: event (mean_score=67.54, mean_share=0.18, active_ratio=1.00).
- Japan: market_food (mean_score=51.02, mean_share=0.29, active_ratio=0.42).
- China: market_food (mean_score=50.34, mean_share=0.18, active_ratio=0.50).
- Taiwan: event (mean_score=54.50, mean_share=0.18, active_ratio=0.50).
- Poland: market_food (mean_score=50.34, mean_share=0.21, active_ratio=0.42).
- Nigeria: event (mean_score=70.67, mean_share=0.18, active_ratio=1.00).

## V4.3.1 Peak Attribution & Event Alignment Hardening

- Peak-Klassen: event_supported=0/30, weakly_supported=4/30, globally_co_moving_or_background=0/30, model_driven=26/30.
- Top-Peaks mit Attribution:
- Ukraine / 2026-02: score=79.51, attr=weakly_supported_peak, event=weakly_supported, global_share=0.77, country_share=0.23, driver=market_food.
- Iran / 2025-08: score=77.97, attr=model_driven_peak, event=not_event_validated, global_share=0.75, country_share=0.25, driver=market_food.
- Nigeria / 2025-07: score=75.60, attr=model_driven_peak, event=not_event_validated, global_share=0.79, country_share=0.21, driver=market_food.
- Russia / 2026-02: score=74.24, attr=model_driven_peak, event=weakly_supported, global_share=0.82, country_share=0.18, driver=market_food.
- Israel / 2025-12: score=70.28, attr=model_driven_peak, event=not_event_validated, global_share=0.79, country_share=0.21, driver=market_food.
- China / 2026-02: score=65.42, attr=model_driven_peak, event=weakly_supported, global_share=0.93, country_share=0.07, driver=market_food.
- Taiwan / 2025-08: score=61.92, attr=model_driven_peak, event=not_event_validated, global_share=0.95, country_share=0.05, driver=market_food.
- Poland / 2026-02: score=54.86, attr=model_driven_peak, event=weakly_supported, global_share=1.00, country_share=0.00, driver=market_food.
- Germany / 2025-12: score=47.74, attr=model_driven_peak, event=weakly_supported, global_share=1.00, country_share=0.00, driver=market_food.
- Japan / 2025-12: score=37.56, attr=model_driven_peak, event=not_event_validated, global_share=1.00, country_share=0.00, driver=market_food.

- Synchronisierte Peak-Cluster:
- 2025-06: peak_ratio=0.30, class=country_specific_wave, countries=Germany|Iran|Japan, wave_group=market_food.
- 2025-07: peak_ratio=0.50, class=moderately_synchronized_wave, countries=Israel|Japan|Nigeria|Russia|Ukraine, wave_group=market_food.
- 2025-08: peak_ratio=0.60, class=highly_synchronized_wave, countries=China|Iran|Poland|Russia|Taiwan|Ukraine, wave_group=market_food.
- 2025-11: peak_ratio=0.10, class=country_specific_wave, countries=Germany, wave_group=market_food.
- 2025-12: peak_ratio=0.40, class=moderately_synchronized_wave, countries=Germany|Iran|Israel|Japan, wave_group=market_food.
- 2026-01: peak_ratio=0.30, class=country_specific_wave, countries=China|Israel|Nigeria, wave_group=market_food.
- 2026-02: peak_ratio=0.60, class=highly_synchronized_wave, countries=China|Nigeria|Poland|Russia|Taiwan|Ukraine, wave_group=market_food.
- 2026-03: peak_ratio=0.20, class=country_specific_wave, countries=Poland|Taiwan, wave_group=market_food.

- Trajectory-Profile:
- Germany: profile=weak_country_specificity, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.57, differentiation=False.
- Israel: profile=weak_country_specificity, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.68, differentiation=False.
- Iran: profile=broad_multi-layer_stress, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.76, differentiation=False.
- Ukraine: profile=broad_multi-layer_stress, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.74, differentiation=False.
- Russia: profile=broad_multi-layer_stress, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.69, differentiation=False.
- Japan: profile=weak_country_specificity, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.50, differentiation=False.
- China: profile=weak_country_specificity, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.63, differentiation=False.
- Taiwan: profile=weak_country_specificity, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.67, differentiation=False.
- Poland: profile=weak_country_specificity, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.59, differentiation=False.
- Nigeria: profile=broad_multi-layer_stress, country_specific_ratio=0.00, global_ratio=0.00, mean_peak_conf=0.74, differentiation=False.

## V4.3.2 Analyst Event Registry & Real-World Alignment

- Registry-Eintraege: 30, Peak-Event-Matches: 30, Global credible ratio=0.70, no_match_ratio=0.03, multi_overlap_ratio=0.17.
- Match-Klassen: direct=10, context=6, weak=8, no_credible=1, multi_overlap=5.
- Country alignment maturity:
- Germany: maturity=medium (0.46), credible=0.33, mean_match_conf=0.54, uncertainties=weak_match_share_present.
- Israel: maturity=medium (0.63), credible=0.67, mean_match_conf=0.62, uncertainties=weak_match_share_present.
- Iran: maturity=medium (0.63), credible=0.67, mean_match_conf=0.68, uncertainties=weak_match_share_present|multi_event_overlap_manual_review.
- Ukraine: maturity=medium (0.53), credible=0.67, mean_match_conf=0.55, uncertainties=peaks_without_credible_match|multi_event_overlap_manual_review.
- Russia: maturity=high (0.88), credible=1.00, mean_match_conf=0.74, uncertainties=none.
- Japan: maturity=low (0.37), credible=0.33, mean_match_conf=0.49, uncertainties=weak_match_share_present.
- China: maturity=high (0.70), credible=1.00, mean_match_conf=0.65, uncertainties=multi_event_overlap_manual_review.
- Taiwan: maturity=high (0.96), credible=1.00, mean_match_conf=0.73, uncertainties=none.
- Poland: maturity=medium (0.47), credible=0.33, mean_match_conf=0.55, uncertainties=weak_match_share_present.
- Nigeria: maturity=high (0.79), credible=1.00, mean_match_conf=0.73, uncertainties=multi_event_overlap_manual_review.

- Top-Peaks mit Realwelt-Zuordnung:
- Ukraine / 2026-02: score=79.51, match=multi_event_overlap, match_conf=0.75, event=Renewed strike and mobility stress, trajectory=broad_multi-layer_stress.
- Iran / 2025-08: score=77.97, match=direct_match, match_conf=0.76, event=Sanctions and currency pressure phase, trajectory=broad_multi-layer_stress.
- Nigeria / 2025-07: score=75.60, match=direct_match, match_conf=0.83, event=Food price and fiscal stress corridor, trajectory=broad_multi-layer_stress.
- Russia / 2026-02: score=74.24, match=plausible_context_match, match_conf=0.68, event=Mobilization and security control cycle, trajectory=broad_multi-layer_stress.
- Israel / 2025-12: score=70.28, match=plausible_context_match, match_conf=0.65, event=Gaza border escalation window, trajectory=weak_country_specificity.
- China / 2026-02: score=65.42, match=plausible_context_match, match_conf=0.59, event=Taiwan strait signaling rise, trajectory=weak_country_specificity.
- Taiwan / 2025-08: score=61.92, match=direct_match, match_conf=0.70, event=Economic technology policy friction, trajectory=weak_country_specificity.
- Poland / 2026-02: score=54.86, match=weak_match, match_conf=0.47, event=Domestic protest and institutional contest, trajectory=weak_country_specificity.
- Germany / 2025-12: score=47.74, match=weak_match, match_conf=0.45, event=Coalition budget stress phase, trajectory=weak_country_specificity.
- Japan / 2025-12: score=37.56, match=weak_match, match_conf=0.46, event=Regional maritime alert pulse, trajectory=weak_country_specificity.

## Top historical review candidates

- Scope: `cluster_score` fuer `tension` und `escalation`; `vulnerability` ist derzeit baseline-artig und standardmaessig ausgeschlossen.
- Hinweis: Kandidaten sind analystenorientierte Pruefpunkte; Low-Coverage-Punkte sind nicht als voll validierte historische Peaks zu lesen.

- #1 Taiwan / gesellschaftlich-politische Spannung / 2026-01-22: 60.96 (hoch, zunehmend), valid (7/5), confidence=86.33 (hoch), driver=crisis_subscore, snapshot_relation=before_snapshot_source
- #2 China / gesellschaftlich-politische Spannung / 2026-02-18: 69.05 (hoch, zunehmend), valid (7/5), confidence=89.17 (hoch), driver=negativity_subscore, snapshot_relation=before_snapshot_source
- #3 Nigeria / gewaltsame Eskalation / 2026-03-15: 72.31 (hoch, rückläufig), valid (7/5), confidence=90.31 (hoch), driver=peak_subscore, snapshot_relation=before_snapshot_source
- #4 China / gesellschaftlich-politische Spannung / 2026-02-25: 67.53 (hoch, rückläufig), valid (7/5), confidence=88.64 (hoch), driver=crisis_subscore, snapshot_relation=before_snapshot_source
- #5 Israel / gewaltsame Eskalation / 2026-02-11: 73.95 (hoch, rückläufig), valid (7/5), confidence=90.88 (hoch), driver=peak_subscore, snapshot_relation=before_snapshot_source

## V3.1 Layer/Fusion Snapshot (zusaetzlich)

- Gruppenstatus: `ok`=berechnet, `limited`=teilweise Quellabdeckung, `not_available`=keine verwertbaren Quellen.
- Hinweis: Der Fusion-Pfad ist ein zusaetzlicher Ergebnisraum und ersetzt die Cluster-Sicht nicht.

- Germany: Fusion=23.18, Confidence=91.39 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Israel: Fusion=40.02, Confidence=91.50 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Iran: Fusion=54.39, Confidence=91.90 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Ukraine: Fusion=53.08, Confidence=91.82 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Russia: Fusion=49.13, Confidence=91.74 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Japan: Fusion=17.72, Confidence=91.34 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- China: Fusion=36.38, Confidence=91.59 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Taiwan: Fusion=41.59, Confidence=91.81 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Poland: Fusion=29.38, Confidence=91.44 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)
- Nigeria: Fusion=50.12, Confidence=91.76 (hoch), Gruppen verfuegbar=7/7, Bonus=nein (0.00)

## V3.2 Historical Fusion View (zusaetzlich)

- Hinweis: Dies ist ein eigener historischer Multi-Layer-Ergebnisraum neben der Cluster-Historie.

- Germany: 2026-04 -> Fusion=23.18 (niedrig, stabil), Confidence=91.39 (hoch), Coverage=7/7 (1.00), Top-Beitraege=market_food (4.47); shock (4.27), staerkste Aenderung=event (-3.74), Interpretation=standard
- Israel: 2026-04 -> Fusion=40.02 (erhoeht, ruecklaeufig), Confidence=91.50 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (7.55); structural (7.11), staerkste Aenderung=narrative (-17.13), Interpretation=standard
- Iran: 2026-04 -> Fusion=54.39 (erhoeht, ruecklaeufig), Confidence=91.90 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (10.52); structural (10.00), staerkste Aenderung=market_food (-29.48), Interpretation=standard
- Ukraine: 2026-04 -> Fusion=53.08 (erhoeht, ruecklaeufig), Confidence=91.82 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (10.27); structural (9.60), staerkste Aenderung=market_food (-38.22), Interpretation=standard
- Russia: 2026-04 -> Fusion=49.13 (erhoeht, ruecklaeufig), Confidence=91.74 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (9.31); structural (8.54), staerkste Aenderung=market_food (-30.84), Interpretation=standard
- Japan: 2026-04 -> Fusion=17.72 (niedrig, stabil), Confidence=91.34 (hoch), Coverage=7/7 (1.00), Top-Beitraege=narrative (3.34); shock (3.03), staerkste Aenderung=event (-3.11), Interpretation=standard
- China: 2026-04 -> Fusion=36.38 (erhoeht, ruecklaeufig), Confidence=91.59 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (6.95); governance (5.94), staerkste Aenderung=market_food (-30.53), Interpretation=standard
- Taiwan: 2026-04 -> Fusion=41.59 (erhoeht, ruecklaeufig), Confidence=91.81 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (8.07); governance (6.87), staerkste Aenderung=market_food (-42.83), Interpretation=standard
- Poland: 2026-04 -> Fusion=29.38 (niedrig, ruecklaeufig), Confidence=91.44 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (6.03); governance (5.10), staerkste Aenderung=market_food (-37.59), Interpretation=standard
- Nigeria: 2026-04 -> Fusion=50.12 (erhoeht, ruecklaeufig), Confidence=91.76 (hoch), Coverage=7/7 (1.00), Top-Beitraege=event (9.31); structural (9.06), staerkste Aenderung=market_food (-22.28), Interpretation=standard

## Fusion Plausibility Warnings

- Hinweise sind nicht-blockierend und dienen der analystischen Nachpruefung.

- [INFO] governance_instability_elevated: 3 country snapshot(s) show elevated governance-instability contribution.
- [INFO] trajectory_low_country_specificity: At least one country trajectory lacks clear country-specific peak differentiation.
- [INFO] peak_no_credible_event_match: At least one detected peak has no credible event-registry match and requires analyst review.
- [INFO] event_coverage_sparse: Event-registry coverage is sparse for at least one country trajectory.
- [INFO] multi_event_overlap_review: At least one peak overlaps multiple plausible events and needs manual analyst review.
- [WARN] trajectory_weak_event_grounding: At least one country trajectory is weakly grounded in the current event registry.

## V4.2 Governance, Validation & Operational Freshness (zusaetzlich)

- Status: calibrated_for_mvp
- Referenzepisoden: 40 (mit Daten: 40)
- Peak-Hit-Rate: 1.00, Timing-Fit-Rate: 0.82, Expected-Group-Hit-Rate: 0.75
- Ranking-Fit: 0.96 (plausible=True)
- Freshness-Coverage: 1.00, Stale-Burden: 0.00, Dynamic-Readiness: 1.00
- Response-Lag-Fit: 0.82, Mean-|Lag|: 0.62 Monate, Historical-Mean-|Delta|: 7.96
- Operational-Freshness-Attention: False
- Dominance-Flags: 0, Event-stale: 0, Governance-instability: 3, Governance-stale: 0, Structural-Outlier: 2, Low-Fresh-Coverage: 0, Stale-Burden-Countries: 0
- Hinweis: Peak-hit rate 1.00 across 40 data-backed reference episodes.
- Hinweis: Timing-fit rate 0.82, mean absolute lag 0.62 months.
- Hinweis: Ranking fit 0.96 (plausible=true).
- Hinweis: Freshness coverage 1.00, stale burden 0.00, dynamic readiness 1.00.
- Hinweis: Response-lag fit 0.82 (tolerance=1m), change-detection fit 0.75.

## Snapshot-Plots (gesamt)

![china_escalation_timeseries](plots/snapshot/china_escalation_timeseries.png)
![china_tension_timeseries](plots/snapshot/china_tension_timeseries.png)
![china_vulnerability_timeseries](plots/snapshot/china_vulnerability_timeseries.png)
![germany_escalation_timeseries](plots/snapshot/germany_escalation_timeseries.png)
![germany_tension_timeseries](plots/snapshot/germany_tension_timeseries.png)
![germany_vulnerability_timeseries](plots/snapshot/germany_vulnerability_timeseries.png)
![iran_escalation_timeseries](plots/snapshot/iran_escalation_timeseries.png)
![iran_tension_timeseries](plots/snapshot/iran_tension_timeseries.png)
![iran_vulnerability_timeseries](plots/snapshot/iran_vulnerability_timeseries.png)
![israel_escalation_timeseries](plots/snapshot/israel_escalation_timeseries.png)
![israel_tension_timeseries](plots/snapshot/israel_tension_timeseries.png)
![israel_vulnerability_timeseries](plots/snapshot/israel_vulnerability_timeseries.png)
![japan_escalation_timeseries](plots/snapshot/japan_escalation_timeseries.png)
![japan_tension_timeseries](plots/snapshot/japan_tension_timeseries.png)
![japan_vulnerability_timeseries](plots/snapshot/japan_vulnerability_timeseries.png)
![nigeria_escalation_timeseries](plots/snapshot/nigeria_escalation_timeseries.png)
![nigeria_tension_timeseries](plots/snapshot/nigeria_tension_timeseries.png)
![nigeria_vulnerability_timeseries](plots/snapshot/nigeria_vulnerability_timeseries.png)
![poland_escalation_timeseries](plots/snapshot/poland_escalation_timeseries.png)
![poland_tension_timeseries](plots/snapshot/poland_tension_timeseries.png)
![poland_vulnerability_timeseries](plots/snapshot/poland_vulnerability_timeseries.png)
![russia_escalation_timeseries](plots/snapshot/russia_escalation_timeseries.png)
![russia_tension_timeseries](plots/snapshot/russia_tension_timeseries.png)
![russia_vulnerability_timeseries](plots/snapshot/russia_vulnerability_timeseries.png)
![taiwan_escalation_timeseries](plots/snapshot/taiwan_escalation_timeseries.png)
![taiwan_tension_timeseries](plots/snapshot/taiwan_tension_timeseries.png)
![taiwan_vulnerability_timeseries](plots/snapshot/taiwan_vulnerability_timeseries.png)
![ukraine_escalation_timeseries](plots/snapshot/ukraine_escalation_timeseries.png)
![ukraine_tension_timeseries](plots/snapshot/ukraine_tension_timeseries.png)
![ukraine_vulnerability_timeseries](plots/snapshot/ukraine_vulnerability_timeseries.png)

## Historical-Trend-Plots Cluster (gesamt)

![historical_cluster_china_escalation_timeseries](plots/historical/clusters/historical_cluster_china_escalation_timeseries.png)
![historical_cluster_china_tension_timeseries](plots/historical/clusters/historical_cluster_china_tension_timeseries.png)
![historical_cluster_china_vulnerability_timeseries](plots/historical/clusters/historical_cluster_china_vulnerability_timeseries.png)
![historical_cluster_germany_escalation_timeseries](plots/historical/clusters/historical_cluster_germany_escalation_timeseries.png)
![historical_cluster_germany_tension_timeseries](plots/historical/clusters/historical_cluster_germany_tension_timeseries.png)
![historical_cluster_germany_vulnerability_timeseries](plots/historical/clusters/historical_cluster_germany_vulnerability_timeseries.png)
![historical_cluster_iran_escalation_timeseries](plots/historical/clusters/historical_cluster_iran_escalation_timeseries.png)
![historical_cluster_iran_tension_timeseries](plots/historical/clusters/historical_cluster_iran_tension_timeseries.png)
![historical_cluster_iran_vulnerability_timeseries](plots/historical/clusters/historical_cluster_iran_vulnerability_timeseries.png)
![historical_cluster_israel_escalation_timeseries](plots/historical/clusters/historical_cluster_israel_escalation_timeseries.png)
![historical_cluster_israel_tension_timeseries](plots/historical/clusters/historical_cluster_israel_tension_timeseries.png)
![historical_cluster_israel_vulnerability_timeseries](plots/historical/clusters/historical_cluster_israel_vulnerability_timeseries.png)
![historical_cluster_japan_escalation_timeseries](plots/historical/clusters/historical_cluster_japan_escalation_timeseries.png)
![historical_cluster_japan_tension_timeseries](plots/historical/clusters/historical_cluster_japan_tension_timeseries.png)
![historical_cluster_japan_vulnerability_timeseries](plots/historical/clusters/historical_cluster_japan_vulnerability_timeseries.png)
![historical_cluster_nigeria_escalation_timeseries](plots/historical/clusters/historical_cluster_nigeria_escalation_timeseries.png)
![historical_cluster_nigeria_tension_timeseries](plots/historical/clusters/historical_cluster_nigeria_tension_timeseries.png)
![historical_cluster_nigeria_vulnerability_timeseries](plots/historical/clusters/historical_cluster_nigeria_vulnerability_timeseries.png)
![historical_cluster_poland_escalation_timeseries](plots/historical/clusters/historical_cluster_poland_escalation_timeseries.png)
![historical_cluster_poland_tension_timeseries](plots/historical/clusters/historical_cluster_poland_tension_timeseries.png)
![historical_cluster_poland_vulnerability_timeseries](plots/historical/clusters/historical_cluster_poland_vulnerability_timeseries.png)
![historical_cluster_russia_escalation_timeseries](plots/historical/clusters/historical_cluster_russia_escalation_timeseries.png)
![historical_cluster_russia_tension_timeseries](plots/historical/clusters/historical_cluster_russia_tension_timeseries.png)
![historical_cluster_russia_vulnerability_timeseries](plots/historical/clusters/historical_cluster_russia_vulnerability_timeseries.png)
![historical_cluster_taiwan_escalation_timeseries](plots/historical/clusters/historical_cluster_taiwan_escalation_timeseries.png)
![historical_cluster_taiwan_tension_timeseries](plots/historical/clusters/historical_cluster_taiwan_tension_timeseries.png)
![historical_cluster_taiwan_vulnerability_timeseries](plots/historical/clusters/historical_cluster_taiwan_vulnerability_timeseries.png)
![historical_cluster_ukraine_escalation_timeseries](plots/historical/clusters/historical_cluster_ukraine_escalation_timeseries.png)
![historical_cluster_ukraine_tension_timeseries](plots/historical/clusters/historical_cluster_ukraine_tension_timeseries.png)
![historical_cluster_ukraine_vulnerability_timeseries](plots/historical/clusters/historical_cluster_ukraine_vulnerability_timeseries.png)

## Historical-Trend-Plots Subscores (gesamt)

![historical_subscores_china_escalation](plots/historical/subscores/historical_subscores_china_escalation.png)
![historical_subscores_china_tension](plots/historical/subscores/historical_subscores_china_tension.png)
![historical_subscores_china_vulnerability](plots/historical/subscores/historical_subscores_china_vulnerability.png)
![historical_subscores_germany_escalation](plots/historical/subscores/historical_subscores_germany_escalation.png)
![historical_subscores_germany_tension](plots/historical/subscores/historical_subscores_germany_tension.png)
![historical_subscores_germany_vulnerability](plots/historical/subscores/historical_subscores_germany_vulnerability.png)
![historical_subscores_iran_escalation](plots/historical/subscores/historical_subscores_iran_escalation.png)
![historical_subscores_iran_tension](plots/historical/subscores/historical_subscores_iran_tension.png)
![historical_subscores_iran_vulnerability](plots/historical/subscores/historical_subscores_iran_vulnerability.png)
![historical_subscores_israel_escalation](plots/historical/subscores/historical_subscores_israel_escalation.png)
![historical_subscores_israel_tension](plots/historical/subscores/historical_subscores_israel_tension.png)
![historical_subscores_israel_vulnerability](plots/historical/subscores/historical_subscores_israel_vulnerability.png)
![historical_subscores_japan_escalation](plots/historical/subscores/historical_subscores_japan_escalation.png)
![historical_subscores_japan_tension](plots/historical/subscores/historical_subscores_japan_tension.png)
![historical_subscores_japan_vulnerability](plots/historical/subscores/historical_subscores_japan_vulnerability.png)
![historical_subscores_nigeria_escalation](plots/historical/subscores/historical_subscores_nigeria_escalation.png)
![historical_subscores_nigeria_tension](plots/historical/subscores/historical_subscores_nigeria_tension.png)
![historical_subscores_nigeria_vulnerability](plots/historical/subscores/historical_subscores_nigeria_vulnerability.png)
![historical_subscores_poland_escalation](plots/historical/subscores/historical_subscores_poland_escalation.png)
![historical_subscores_poland_tension](plots/historical/subscores/historical_subscores_poland_tension.png)
![historical_subscores_poland_vulnerability](plots/historical/subscores/historical_subscores_poland_vulnerability.png)
![historical_subscores_russia_escalation](plots/historical/subscores/historical_subscores_russia_escalation.png)
![historical_subscores_russia_tension](plots/historical/subscores/historical_subscores_russia_tension.png)
![historical_subscores_russia_vulnerability](plots/historical/subscores/historical_subscores_russia_vulnerability.png)
![historical_subscores_taiwan_escalation](plots/historical/subscores/historical_subscores_taiwan_escalation.png)
![historical_subscores_taiwan_tension](plots/historical/subscores/historical_subscores_taiwan_tension.png)
![historical_subscores_taiwan_vulnerability](plots/historical/subscores/historical_subscores_taiwan_vulnerability.png)
![historical_subscores_ukraine_escalation](plots/historical/subscores/historical_subscores_ukraine_escalation.png)
![historical_subscores_ukraine_tension](plots/historical/subscores/historical_subscores_ukraine_tension.png)
![historical_subscores_ukraine_vulnerability](plots/historical/subscores/historical_subscores_ukraine_vulnerability.png)

## V3.1 Fusion-Plots (gesamt)

![fusion_groups_china](plots/fusion/fusion_groups_china.png)
![fusion_groups_germany](plots/fusion/fusion_groups_germany.png)
![fusion_groups_iran](plots/fusion/fusion_groups_iran.png)
![fusion_groups_israel](plots/fusion/fusion_groups_israel.png)
![fusion_groups_japan](plots/fusion/fusion_groups_japan.png)
![fusion_groups_nigeria](plots/fusion/fusion_groups_nigeria.png)
![fusion_groups_poland](plots/fusion/fusion_groups_poland.png)
![fusion_groups_russia](plots/fusion/fusion_groups_russia.png)
![fusion_groups_taiwan](plots/fusion/fusion_groups_taiwan.png)
![fusion_groups_ukraine](plots/fusion/fusion_groups_ukraine.png)

## V3.2 Historical Fusion Group-Plots (gesamt)

![fusion_historical_groups_china](plots/fusion/fusion_historical_groups_china.png)
![fusion_historical_groups_germany](plots/fusion/fusion_historical_groups_germany.png)
![fusion_historical_groups_iran](plots/fusion/fusion_historical_groups_iran.png)
![fusion_historical_groups_israel](plots/fusion/fusion_historical_groups_israel.png)
![fusion_historical_groups_japan](plots/fusion/fusion_historical_groups_japan.png)
![fusion_historical_groups_nigeria](plots/fusion/fusion_historical_groups_nigeria.png)
![fusion_historical_groups_poland](plots/fusion/fusion_historical_groups_poland.png)
![fusion_historical_groups_russia](plots/fusion/fusion_historical_groups_russia.png)
![fusion_historical_groups_taiwan](plots/fusion/fusion_historical_groups_taiwan.png)
![fusion_historical_groups_ukraine](plots/fusion/fusion_historical_groups_ukraine.png)

## V3.2 Historical Fusion Total-Plots (gesamt)

![fusion_historical_total_china](plots/fusion/fusion_historical_total_china.png)
![fusion_historical_total_germany](plots/fusion/fusion_historical_total_germany.png)
![fusion_historical_total_iran](plots/fusion/fusion_historical_total_iran.png)
![fusion_historical_total_israel](plots/fusion/fusion_historical_total_israel.png)
![fusion_historical_total_japan](plots/fusion/fusion_historical_total_japan.png)
![fusion_historical_total_nigeria](plots/fusion/fusion_historical_total_nigeria.png)
![fusion_historical_total_poland](plots/fusion/fusion_historical_total_poland.png)
![fusion_historical_total_russia](plots/fusion/fusion_historical_total_russia.png)
![fusion_historical_total_taiwan](plots/fusion/fusion_historical_total_taiwan.png)
![fusion_historical_total_ukraine](plots/fusion/fusion_historical_total_ukraine.png)

## V4.3 Vergleichsplots (laenderuebergreifend)

![v43_multicountry_fusion_total](plots/fusion/v43_multicountry_fusion_total.png)
![v43_multicountry_ranking_trajectory](plots/fusion/v43_multicountry_ranking_trajectory.png)

## V4.3 Pro-Land-Jahresprofil-Plots (gesamt)

![v43_country_profile_china](plots/fusion/v43_country_profile_china.png)
![v43_country_profile_germany](plots/fusion/v43_country_profile_germany.png)
![v43_country_profile_iran](plots/fusion/v43_country_profile_iran.png)
![v43_country_profile_israel](plots/fusion/v43_country_profile_israel.png)
![v43_country_profile_japan](plots/fusion/v43_country_profile_japan.png)
![v43_country_profile_nigeria](plots/fusion/v43_country_profile_nigeria.png)
![v43_country_profile_poland](plots/fusion/v43_country_profile_poland.png)
![v43_country_profile_russia](plots/fusion/v43_country_profile_russia.png)
![v43_country_profile_taiwan](plots/fusion/v43_country_profile_taiwan.png)
![v43_country_profile_ukraine](plots/fusion/v43_country_profile_ukraine.png)

## V4.3.1 Peak-Synchronisationsplots (gesamt)

![v431_global_peak_synchronization](plots/fusion/v431_global_peak_synchronization.png)

## V4.3.1 Peak-Attributionsplots (gesamt)

![v431_peak_attribution_china](plots/fusion/v431_peak_attribution_china.png)
![v431_peak_attribution_germany](plots/fusion/v431_peak_attribution_germany.png)
![v431_peak_attribution_iran](plots/fusion/v431_peak_attribution_iran.png)
![v431_peak_attribution_israel](plots/fusion/v431_peak_attribution_israel.png)
![v431_peak_attribution_japan](plots/fusion/v431_peak_attribution_japan.png)
![v431_peak_attribution_nigeria](plots/fusion/v431_peak_attribution_nigeria.png)
![v431_peak_attribution_poland](plots/fusion/v431_peak_attribution_poland.png)
![v431_peak_attribution_russia](plots/fusion/v431_peak_attribution_russia.png)
![v431_peak_attribution_taiwan](plots/fusion/v431_peak_attribution_taiwan.png)
![v431_peak_attribution_ukraine](plots/fusion/v431_peak_attribution_ukraine.png)

## V4.3.2 Event-Alignment-Plots (gesamt)

![v432_event_alignment_china](plots/fusion/v432_event_alignment_china.png)
![v432_event_alignment_germany](plots/fusion/v432_event_alignment_germany.png)
![v432_event_alignment_iran](plots/fusion/v432_event_alignment_iran.png)
![v432_event_alignment_israel](plots/fusion/v432_event_alignment_israel.png)
![v432_event_alignment_japan](plots/fusion/v432_event_alignment_japan.png)
![v432_event_alignment_nigeria](plots/fusion/v432_event_alignment_nigeria.png)
![v432_event_alignment_poland](plots/fusion/v432_event_alignment_poland.png)
![v432_event_alignment_russia](plots/fusion/v432_event_alignment_russia.png)
![v432_event_alignment_taiwan](plots/fusion/v432_event_alignment_taiwan.png)
![v432_event_alignment_ukraine](plots/fusion/v432_event_alignment_ukraine.png)

## Germany

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 28.91 (niedrig, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=28.91, max=43.14, min=27.57, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist niedrig; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 24.39 (niedrig, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=24.39, max=35.59, min=24.18, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist niedrig; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 42.93 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=42.93, max=42.93, min=42.93, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist erhöht; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 28.91 (niedrig, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 24.39 (niedrig, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 42.93 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 23.18 (Confidence 91.39 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=market_food (share=0.19), support=narrow (0/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.84, stale_share=0.00, dynamic_ready=True, dominant_fresh=market_food, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 21.68 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 22.46 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 22.35 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 24.82 (Confidence 97.06/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 24.19 (Confidence 87.54/hoch, Coverage 1/1) | sources=narrative_input
- shock: 30.51 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 12.86 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 23.18 (niedrig, stabil), Confidence 91.39/hoch, Coverage=7/7 (1.00), Top-Beitraege=market_food (4.47); shock (4.27), staerkste Aenderung=event (-3.74), Interpretation=standard.
- displacement: 21.68 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 22.46 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 22.35 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 24.82 (status=ok, confidence=97.06/hoch, coverage=2/2)
- narrative: 24.19 (status=ok, confidence=87.54/hoch, coverage=1/1)
- shock: 30.51 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 12.86 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=33.69, range=24.56, volatility=8.52, freshness=fresh_operational.
- Treiberbild: dominant=market_food, support=narrow, fresh_support=broad, stale_support=none.
- Max/Min: 2025-12=47.74, 2026-04=23.18.
- Kritische Peak-Phasen:
- #1 2025-12: 47.74 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=weakly_supported, event_match=weak_match, match_conf=0.45, linked_event=Coalition budget stress phase, global_share=1.00, country_share=0.00.
- #2 2025-06: 43.54 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.66, linked_event=Energy cost adjustment cycle, global_share=1.00, country_share=0.00.
- #3 2025-11: 36.73 (erhoeht), driver=market_food, change=shock, attr=model_driven_peak, event=weakly_supported, event_match=weak_match, match_conf=0.50, linked_event=Coalition budget stress phase, global_share=1.00, country_share=0.00.
- Mittlere Gruppenbeitraege (Top 3):
- market_food: mean=51.02, share=0.26, availability=1.00.
- shock: mean=50.00, share=0.20, availability=1.00.
- event: mean=29.92, share=0.15, availability=1.00.
- Trajectory: weak_country_specificity, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.57, differentiation=False.
- Event-Alignment: maturity=medium (0.46), credible_ratio=0.33, mean_match_conf=0.54, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Coalition budget stress phase | Energy cost adjustment cycle; offene Unsicherheiten=weak_match_share_present.

### 3) Snapshot-Plots (Land)

![germany_escalation_timeseries](plots/snapshot/germany_escalation_timeseries.png)
![germany_tension_timeseries](plots/snapshot/germany_tension_timeseries.png)
![germany_vulnerability_timeseries](plots/snapshot/germany_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_germany_escalation_timeseries](plots/historical/clusters/historical_cluster_germany_escalation_timeseries.png)
![historical_cluster_germany_tension_timeseries](plots/historical/clusters/historical_cluster_germany_tension_timeseries.png)
![historical_cluster_germany_vulnerability_timeseries](plots/historical/clusters/historical_cluster_germany_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_germany_escalation](plots/historical/subscores/historical_subscores_germany_escalation.png)
![historical_subscores_germany_tension](plots/historical/subscores/historical_subscores_germany_tension.png)
![historical_subscores_germany_vulnerability](plots/historical/subscores/historical_subscores_germany_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_germany](plots/fusion/fusion_groups_germany.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_germany](plots/fusion/fusion_historical_groups_germany.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_germany](plots/fusion/fusion_historical_total_germany.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_germany](plots/fusion/v43_country_profile_germany.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_germany](plots/fusion/v431_peak_attribution_germany.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_germany](plots/fusion/v432_event_alignment_germany.png)

## Israel

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 61.61 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=61.61, max=83.08, min=59.54, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist hoch; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 67.30 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=67.30, max=80.21, min=66.82, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist hoch; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 70.90 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=70.90, max=70.90, min=70.90, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 61.61 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 67.30 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 70.90 (hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 40.02 (Confidence 91.50 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=narrow (1/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=structural, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 47.43 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 47.21 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 46.20 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 17.06 (Confidence 95.35/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 37.02 (Confidence 90.02/hoch, Coverage 1/1) | sources=narrative_input
- shock: 28.56 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 71.14 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 40.02 (erhoeht, ruecklaeufig), Confidence 91.50/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (7.55); structural (7.11), staerkste Aenderung=narrative (-17.13), Interpretation=standard.
- displacement: 47.43 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 47.21 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 46.20 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 17.06 (status=ok, confidence=95.35/hoch, coverage=2/2)
- narrative: 37.02 (status=ok, confidence=90.02/hoch, coverage=1/1)
- shock: 28.56 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 71.14 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: volatil, kontinuierlicher; mean=55.90, range=30.43, volatility=10.03, freshness=fresh_operational.
- Treiberbild: dominant=event, support=narrow, fresh_support=broad, stale_support=none.
- Max/Min: 2026-01=70.45, 2026-04=40.02.
- Kritische Peak-Phasen:
- #1 2025-12: 70.28 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=plausible_context_match, match_conf=0.65, linked_event=Gaza border escalation window, global_share=0.79, country_share=0.21.
- #2 2025-07: 66.68 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=weak_match, match_conf=0.51, linked_event=Domestic governance contestation, global_share=0.90, country_share=0.10.
- #3 2026-01: 70.45 (hoch), driver=market_food, change=event, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.70, linked_event=Regional alert and strike cycle, global_share=0.86, country_share=0.14.
- Mittlere Gruppenbeitraege (Top 3):
- event: mean=60.12, share=0.18, availability=1.00.
- market_food: mean=50.68, share=0.15, availability=1.00.
- governance: mean=54.78, share=0.15, availability=1.00.
- Trajectory: weak_country_specificity, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.68, differentiation=False.
- Event-Alignment: maturity=medium (0.63), credible_ratio=0.67, mean_match_conf=0.62, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Gaza border escalation window | Domestic governance contestation | Regional alert and strike cycle; offene Unsicherheiten=weak_match_share_present.

### 3) Snapshot-Plots (Land)

![israel_escalation_timeseries](plots/snapshot/israel_escalation_timeseries.png)
![israel_tension_timeseries](plots/snapshot/israel_tension_timeseries.png)
![israel_vulnerability_timeseries](plots/snapshot/israel_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_israel_escalation_timeseries](plots/historical/clusters/historical_cluster_israel_escalation_timeseries.png)
![historical_cluster_israel_tension_timeseries](plots/historical/clusters/historical_cluster_israel_tension_timeseries.png)
![historical_cluster_israel_vulnerability_timeseries](plots/historical/clusters/historical_cluster_israel_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_israel_escalation](plots/historical/subscores/historical_subscores_israel_escalation.png)
![historical_subscores_israel_tension](plots/historical/subscores/historical_subscores_israel_tension.png)
![historical_subscores_israel_vulnerability](plots/historical/subscores/historical_subscores_israel_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_israel](plots/fusion/fusion_groups_israel.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_israel](plots/fusion/fusion_historical_groups_israel.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_israel](plots/fusion/fusion_historical_total_israel.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_israel](plots/fusion/v43_country_profile_israel.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_israel](plots/fusion/v431_peak_attribution_israel.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_israel](plots/fusion/v432_event_alignment_israel.png)

## Iran

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 80.43 (sehr hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=80.43, max=95.12, min=79.30, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist sehr hoch; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 82.67 (sehr hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=82.67, max=91.43, min=82.03, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist sehr hoch; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 87.83 (sehr hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=87.83, max=87.83, min=87.83, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist sehr hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 80.43 (sehr hoch, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 82.67 (sehr hoch, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 87.83 (sehr hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 54.39 (Confidence 91.90 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=broad (5/7 aktiv), event_stale=False, governance_instability=True, governance_stale=False, structural_outlier=True.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=structural, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 63.78 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 65.75 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 63.13 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 18.78 (Confidence 96.56/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 63.94 (Confidence 91.62/hoch, Coverage 1/1) | sources=narrative_input
- shock: 26.95 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 100.00 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 54.39 (erhoeht, ruecklaeufig), Confidence 91.90/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (10.52); structural (10.00), staerkste Aenderung=market_food (-29.48), Interpretation=standard.
- displacement: 63.78 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 65.75 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 63.13 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 18.78 (status=ok, confidence=96.56/hoch, coverage=2/2)
- narrative: 63.94 (status=ok, confidence=91.62/hoch, coverage=1/1)
- shock: 26.95 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 100.00 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=68.01, range=24.38, volatility=9.18, freshness=fresh_operational.
- Treiberbild: dominant=event, support=broad, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=78.37, 2025-10=53.99.
- Kritische Peak-Phasen:
- #1 2025-08: 77.97 (hoch), driver=market_food, change=event, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.76, linked_event=Sanctions and currency pressure phase, global_share=0.75, country_share=0.25.
- #2 2025-06: 76.73 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=weak_match, match_conf=0.54, linked_event=Sanctions and currency pressure phase, global_share=0.72, country_share=0.28.
- #3 2025-12: 70.23 (hoch), driver=event, change=market_food, attr=weakly_supported_peak, event=weakly_supported, event_match=multi_event_overlap, match_conf=0.73, linked_event=Proxy confrontation escalation, global_share=0.79, country_share=0.21.
- Mittlere Gruppenbeitraege (Top 3):
- event: mean=76.75, share=0.18, availability=1.00.
- governance: mean=70.47, share=0.16, availability=1.00.
- structural: mean=98.40, share=0.15, availability=1.00.
- Trajectory: broad_multi-layer_stress, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.76, differentiation=False.
- Event-Alignment: maturity=medium (0.63), credible_ratio=0.67, mean_match_conf=0.68, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Sanctions and currency pressure phase | Proxy confrontation escalation; offene Unsicherheiten=weak_match_share_present|multi_event_overlap_manual_review.

### 3) Snapshot-Plots (Land)

![iran_escalation_timeseries](plots/snapshot/iran_escalation_timeseries.png)
![iran_tension_timeseries](plots/snapshot/iran_tension_timeseries.png)
![iran_vulnerability_timeseries](plots/snapshot/iran_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_iran_escalation_timeseries](plots/historical/clusters/historical_cluster_iran_escalation_timeseries.png)
![historical_cluster_iran_tension_timeseries](plots/historical/clusters/historical_cluster_iran_tension_timeseries.png)
![historical_cluster_iran_vulnerability_timeseries](plots/historical/clusters/historical_cluster_iran_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_iran_escalation](plots/historical/subscores/historical_subscores_iran_escalation.png)
![historical_subscores_iran_tension](plots/historical/subscores/historical_subscores_iran_tension.png)
![historical_subscores_iran_vulnerability](plots/historical/subscores/historical_subscores_iran_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_iran](plots/fusion/fusion_groups_iran.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_iran](plots/fusion/fusion_historical_groups_iran.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_iran](plots/fusion/fusion_historical_total_iran.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_iran](plots/fusion/v43_country_profile_iran.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_iran](plots/fusion/v431_peak_attribution_iran.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_iran](plots/fusion/v432_event_alignment_iran.png)

## Ukraine

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 75.36 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=75.36, max=94.98, min=73.69, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist hoch; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 80.44 (sehr hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=80.44, max=91.60, min=79.08, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist sehr hoch; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 82.73 (sehr hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=82.73, max=82.73, min=82.73, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist sehr hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 75.36 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 80.44 (sehr hoch, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 82.73 (sehr hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 53.08 (Confidence 91.82 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=broad (5/7 aktiv), event_stale=False, governance_instability=True, governance_stale=False, structural_outlier=True.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=structural, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 60.09 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 64.18 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 59.49 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 20.21 (Confidence 96.33/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 61.78 (Confidence 91.29/hoch, Coverage 1/1) | sources=narrative_input
- shock: 29.89 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 96.00 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 53.08 (erhoeht, ruecklaeufig), Confidence 91.82/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (10.27); structural (9.60), staerkste Aenderung=market_food (-38.22), Interpretation=standard.
- displacement: 60.09 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 64.18 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 59.49 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 20.21 (status=ok, confidence=96.33/hoch, coverage=2/2)
- narrative: 61.78 (status=ok, confidence=91.29/hoch, coverage=1/1)
- shock: 29.89 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 96.00 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=65.02, range=27.18, volatility=9.10, freshness=fresh_operational.
- Treiberbild: dominant=event, support=broad, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=79.51, 2025-10=52.33.
- Kritische Peak-Phasen:
- #1 2026-02: 79.51 (hoch), driver=market_food, change=market_food, attr=weakly_supported_peak, event=weakly_supported, event_match=multi_event_overlap, match_conf=0.75, linked_event=Renewed strike and mobility stress, global_share=0.77, country_share=0.23.
- #2 2025-08: 77.67 (hoch), driver=market_food, change=event, attr=model_driven_peak, event=not_event_validated, event_match=plausible_context_match, match_conf=0.59, linked_event=Frontline intensity surge, global_share=0.76, country_share=0.24.
- #3 2025-07: 74.75 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=no_credible_match, match_conf=0.33, linked_event=Winter infrastructure pressure, global_share=0.80, country_share=0.20.
- Mittlere Gruppenbeitraege (Top 3):
- event: mean=73.17, share=0.18, availability=1.00.
- governance: mean=67.11, share=0.16, availability=1.00.
- narrative: mean=66.37, share=0.14, availability=1.00.
- Trajectory: broad_multi-layer_stress, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.74, differentiation=False.
- Event-Alignment: maturity=medium (0.53), credible_ratio=0.67, mean_match_conf=0.55, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Renewed strike and mobility stress | Frontline intensity surge | Winter infrastructure pressure; offene Unsicherheiten=peaks_without_credible_match|multi_event_overlap_manual_review.

### 3) Snapshot-Plots (Land)

![ukraine_escalation_timeseries](plots/snapshot/ukraine_escalation_timeseries.png)
![ukraine_tension_timeseries](plots/snapshot/ukraine_tension_timeseries.png)
![ukraine_vulnerability_timeseries](plots/snapshot/ukraine_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_ukraine_escalation_timeseries](plots/historical/clusters/historical_cluster_ukraine_escalation_timeseries.png)
![historical_cluster_ukraine_tension_timeseries](plots/historical/clusters/historical_cluster_ukraine_tension_timeseries.png)
![historical_cluster_ukraine_vulnerability_timeseries](plots/historical/clusters/historical_cluster_ukraine_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_ukraine_escalation](plots/historical/subscores/historical_subscores_ukraine_escalation.png)
![historical_subscores_ukraine_tension](plots/historical/subscores/historical_subscores_ukraine_tension.png)
![historical_subscores_ukraine_vulnerability](plots/historical/subscores/historical_subscores_ukraine_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_ukraine](plots/fusion/fusion_groups_ukraine.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_ukraine](plots/fusion/fusion_historical_groups_ukraine.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_ukraine](plots/fusion/fusion_historical_total_ukraine.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_ukraine](plots/fusion/v43_country_profile_ukraine.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_ukraine](plots/fusion/v431_peak_attribution_ukraine.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_ukraine](plots/fusion/v432_event_alignment_ukraine.png)

## Russia

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 70.23 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=70.23, max=92.00, min=67.61, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist hoch; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 74.38 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=74.38, max=87.34, min=73.44, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist hoch; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 77.63 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=77.63, max=77.63, min=77.63, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 70.23 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 74.38 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 77.63 (hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 49.13 (Confidence 91.74 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=broad (3/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=structural, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 54.82 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 58.20 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 53.94 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 20.34 (Confidence 96.30/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 58.47 (Confidence 90.77/hoch, Coverage 1/1) | sources=narrative_input
- shock: 30.06 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 85.43 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 49.13 (erhoeht, ruecklaeufig), Confidence 91.74/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (9.31); structural (8.54), staerkste Aenderung=market_food (-30.84), Interpretation=standard.
- displacement: 54.82 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 58.20 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 53.94 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 20.34 (status=ok, confidence=96.30/hoch, coverage=2/2)
- narrative: 58.47 (status=ok, confidence=90.77/hoch, coverage=1/1)
- shock: 30.06 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 85.43 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=60.91, range=26.11, volatility=9.01, freshness=fresh_operational.
- Treiberbild: dominant=event, support=broad, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=74.24, 2025-10=48.13.
- Kritische Peak-Phasen:
- #1 2026-02: 74.24 (hoch), driver=market_food, change=event, attr=model_driven_peak, event=weakly_supported, event_match=plausible_context_match, match_conf=0.68, linked_event=Mobilization and security control cycle, global_share=0.82, country_share=0.18.
- #2 2025-08: 73.06 (hoch), driver=market_food, change=event, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.72, linked_event=Domestic economic pressure corridor, global_share=0.81, country_share=0.19.
- #3 2025-07: 73.10 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.82, linked_event=Domestic economic pressure corridor, global_share=0.82, country_share=0.18.
- Mittlere Gruppenbeitraege (Top 3):
- event: mean=67.54, share=0.18, availability=1.00.
- governance: mean=61.35, share=0.15, availability=1.00.
- narrative: mean=62.89, share=0.15, availability=1.00.
- Trajectory: broad_multi-layer_stress, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.69, differentiation=False.
- Event-Alignment: maturity=high (0.88), credible_ratio=1.00, mean_match_conf=0.74, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Domestic economic pressure corridor | Mobilization and security control cycle; offene Unsicherheiten=none.

### 3) Snapshot-Plots (Land)

![russia_escalation_timeseries](plots/snapshot/russia_escalation_timeseries.png)
![russia_tension_timeseries](plots/snapshot/russia_tension_timeseries.png)
![russia_vulnerability_timeseries](plots/snapshot/russia_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_russia_escalation_timeseries](plots/historical/clusters/historical_cluster_russia_escalation_timeseries.png)
![historical_cluster_russia_tension_timeseries](plots/historical/clusters/historical_cluster_russia_tension_timeseries.png)
![historical_cluster_russia_vulnerability_timeseries](plots/historical/clusters/historical_cluster_russia_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_russia_escalation](plots/historical/subscores/historical_subscores_russia_escalation.png)
![historical_subscores_russia_tension](plots/historical/subscores/historical_subscores_russia_tension.png)
![historical_subscores_russia_vulnerability](plots/historical/subscores/historical_subscores_russia_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_russia](plots/fusion/fusion_groups_russia.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_russia](plots/fusion/fusion_historical_groups_russia.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_russia](plots/fusion/fusion_historical_total_russia.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_russia](plots/fusion/v43_country_profile_russia.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_russia](plots/fusion/v431_peak_attribution_russia.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_russia](plots/fusion/v432_event_alignment_russia.png)

## Japan

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 23.76 (niedrig, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=23.76, max=34.16, min=22.86, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist niedrig; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 20.12 (niedrig, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=20.12, max=27.31, min=19.25, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist niedrig; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 38.70 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=38.70, max=38.70, min=38.70, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist erhöht; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 23.76 (niedrig, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 20.12 (niedrig, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 38.70 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 17.72 (Confidence 91.34 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=narrative (share=0.19), support=narrow (0/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.83, stale_share=0.00, dynamic_ready=True, dominant_fresh=narrative, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 17.79 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 18.65 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 18.99 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 15.60 (Confidence 97.08/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 23.83 (Confidence 87.17/hoch, Coverage 1/1) | sources=narrative_input
- shock: 21.66 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 4.00 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 17.72 (niedrig, stabil), Confidence 91.34/hoch, Coverage=7/7 (1.00), Top-Beitraege=narrative (3.34); shock (3.03), staerkste Aenderung=event (-3.11), Interpretation=standard.
- displacement: 17.79 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 18.65 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 18.99 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 15.60 (status=ok, confidence=97.08/hoch, coverage=2/2)
- narrative: 23.83 (status=ok, confidence=87.17/hoch, coverage=1/1)
- shock: 21.66 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 4.00 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=29.74, range=21.01, volatility=6.97, freshness=fresh_operational.
- Treiberbild: dominant=narrative, support=narrow, fresh_support=broad, stale_support=none.
- Max/Min: 2025-07=38.73, 2026-04=17.72.
- Kritische Peak-Phasen:
- #1 2025-12: 37.56 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=weak_match, match_conf=0.46, linked_event=Regional maritime alert pulse, global_share=1.00, country_share=0.00.
- #2 2025-06: 37.11 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=weak_match, match_conf=0.42, linked_event=Yen volatility and policy response, global_share=1.00, country_share=0.00.
- #3 2025-07: 38.73 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=plausible_context_match, match_conf=0.60, linked_event=Yen volatility and policy response, global_share=1.00, country_share=0.00.
- Mittlere Gruppenbeitraege (Top 3):
- market_food: mean=51.02, share=0.29, availability=1.00.
- shock: mean=50.00, share=0.23, availability=1.00.
- event: mean=23.73, share=0.14, availability=1.00.
- Trajectory: weak_country_specificity, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.50, differentiation=False.
- Event-Alignment: maturity=low (0.37), credible_ratio=0.33, mean_match_conf=0.49, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Yen volatility and policy response | Regional maritime alert pulse; offene Unsicherheiten=weak_match_share_present.

### 3) Snapshot-Plots (Land)

![japan_escalation_timeseries](plots/snapshot/japan_escalation_timeseries.png)
![japan_tension_timeseries](plots/snapshot/japan_tension_timeseries.png)
![japan_vulnerability_timeseries](plots/snapshot/japan_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_japan_escalation_timeseries](plots/historical/clusters/historical_cluster_japan_escalation_timeseries.png)
![historical_cluster_japan_tension_timeseries](plots/historical/clusters/historical_cluster_japan_tension_timeseries.png)
![historical_cluster_japan_vulnerability_timeseries](plots/historical/clusters/historical_cluster_japan_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_japan_escalation](plots/historical/subscores/historical_subscores_japan_escalation.png)
![historical_subscores_japan_tension](plots/historical/subscores/historical_subscores_japan_tension.png)
![historical_subscores_japan_vulnerability](plots/historical/subscores/historical_subscores_japan_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_japan](plots/fusion/fusion_groups_japan.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_japan](plots/fusion/fusion_historical_groups_japan.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_japan](plots/fusion/fusion_historical_total_japan.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_japan](plots/fusion/v43_country_profile_japan.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_japan](plots/fusion/v431_peak_attribution_japan.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_japan](plots/fusion/v432_event_alignment_japan.png)

## China

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 51.71 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=51.71, max=69.36, min=49.03, Tage hoch/sehr hoch=197, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist erhöht; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 53.53 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=53.53, max=63.04, min=51.98, Tage hoch/sehr hoch=208, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist erhöht; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 61.57 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=61.57, max=61.57, min=61.57, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 51.71 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 53.53 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 61.57 (hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 36.38 (Confidence 91.59 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=narrow (0/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=governance, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 40.26 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 43.44 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 39.62 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 18.23 (Confidence 96.65/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 35.13 (Confidence 89.37/hoch, Coverage 1/1) | sources=narrative_input
- shock: 34.86 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 51.71 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 36.38 (erhoeht, ruecklaeufig), Confidence 91.59/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (6.95); governance (5.94), staerkste Aenderung=market_food (-30.53), Interpretation=standard.
- displacement: 40.26 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 43.44 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 39.62 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 18.23 (status=ok, confidence=96.65/hoch, coverage=2/2)
- narrative: 35.13 (status=ok, confidence=89.37/hoch, coverage=1/1)
- shock: 34.86 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 51.71 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=47.11, range=29.47, volatility=8.47, freshness=fresh_operational.
- Treiberbild: dominant=event, support=narrow, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=65.42, 2025-10=35.95.
- Kritische Peak-Phasen:
- #1 2026-02: 65.42 (hoch), driver=market_food, change=shock, attr=model_driven_peak, event=weakly_supported, event_match=plausible_context_match, match_conf=0.59, linked_event=Taiwan strait signaling rise, global_share=0.93, country_share=0.07.
- #2 2025-08: 56.33 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=multi_event_overlap, match_conf=0.70, linked_event=Industrial demand slowdown phase, global_share=1.00, country_share=0.00.
- #3 2026-01: 54.61 (erhoeht), driver=market_food, change=narrative, attr=model_driven_peak, event=weakly_supported, event_match=multi_event_overlap, match_conf=0.66, linked_event=Taiwan strait signaling rise, global_share=1.00, country_share=0.00.
- Mittlere Gruppenbeitraege (Top 3):
- market_food: mean=50.34, share=0.18, availability=1.00.
- event: mean=49.53, share=0.17, availability=1.00.
- shock: mean=50.00, share=0.15, availability=1.00.
- Trajectory: weak_country_specificity, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.63, differentiation=False.
- Event-Alignment: maturity=high (0.70), credible_ratio=1.00, mean_match_conf=0.65, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Taiwan strait signaling rise | Industrial demand slowdown phase; offene Unsicherheiten=multi_event_overlap_manual_review.

### 3) Snapshot-Plots (Land)

![china_escalation_timeseries](plots/snapshot/china_escalation_timeseries.png)
![china_tension_timeseries](plots/snapshot/china_tension_timeseries.png)
![china_vulnerability_timeseries](plots/snapshot/china_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_china_escalation_timeseries](plots/historical/clusters/historical_cluster_china_escalation_timeseries.png)
![historical_cluster_china_tension_timeseries](plots/historical/clusters/historical_cluster_china_tension_timeseries.png)
![historical_cluster_china_vulnerability_timeseries](plots/historical/clusters/historical_cluster_china_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_china_escalation](plots/historical/subscores/historical_subscores_china_escalation.png)
![historical_subscores_china_tension](plots/historical/subscores/historical_subscores_china_tension.png)
![historical_subscores_china_vulnerability](plots/historical/subscores/historical_subscores_china_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_china](plots/fusion/fusion_groups_china.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_china](plots/fusion/fusion_historical_groups_china.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_china](plots/fusion/fusion_historical_total_china.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_china](plots/fusion/v43_country_profile_china.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_china](plots/fusion/v431_peak_attribution_china.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_china](plots/fusion/v432_event_alignment_china.png)

## Taiwan

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 58.08 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=58.08, max=73.19, min=54.19, Tage hoch/sehr hoch=306, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist hoch; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 61.40 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=61.40, max=70.46, min=59.36, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist hoch; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 65.80 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=65.80, max=65.80, min=65.80, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 58.08 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 61.40 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 65.80 (hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 41.59 (Confidence 91.81 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=narrow (1/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=governance, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 46.15 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 50.42 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 45.80 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 30.60 (Confidence 97.60/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 36.88 (Confidence 89.97/hoch, Coverage 1/1) | sources=narrative_input
- shock: 28.06 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 60.57 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 41.59 (erhoeht, ruecklaeufig), Confidence 91.81/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (8.07); governance (6.87), staerkste Aenderung=market_food (-42.83), Interpretation=standard.
- displacement: 46.15 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 50.42 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 45.80 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 30.60 (status=ok, confidence=97.60/hoch, coverage=2/2)
- narrative: 36.88 (status=ok, confidence=89.97/hoch, coverage=1/1)
- shock: 28.06 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 60.57 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=51.05, range=23.85, volatility=8.60, freshness=fresh_operational.
- Treiberbild: dominant=event, support=narrow, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=61.96, 2025-10=38.11.
- Kritische Peak-Phasen:
- #1 2025-08: 61.92 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.70, linked_event=Economic technology policy friction, global_share=0.95, country_share=0.05.
- #2 2026-03: 59.93 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=weakly_supported, event_match=direct_match, match_conf=0.75, linked_event=Cross strait election cycle pressure, global_share=0.82, country_share=0.18.
- #3 2026-02: 61.96 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=weakly_supported, event_match=direct_match, match_conf=0.73, linked_event=Cross strait election cycle pressure, global_share=0.98, country_share=0.02.
- Mittlere Gruppenbeitraege (Top 3):
- event: mean=54.50, share=0.18, availability=1.00.
- market_food: mean=50.34, share=0.17, availability=1.00.
- governance: mean=48.59, share=0.15, availability=1.00.
- Trajectory: weak_country_specificity, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.67, differentiation=False.
- Event-Alignment: maturity=high (0.96), credible_ratio=1.00, mean_match_conf=0.73, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Cross strait election cycle pressure | Economic technology policy friction; offene Unsicherheiten=none.

### 3) Snapshot-Plots (Land)

![taiwan_escalation_timeseries](plots/snapshot/taiwan_escalation_timeseries.png)
![taiwan_tension_timeseries](plots/snapshot/taiwan_tension_timeseries.png)
![taiwan_vulnerability_timeseries](plots/snapshot/taiwan_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_taiwan_escalation_timeseries](plots/historical/clusters/historical_cluster_taiwan_escalation_timeseries.png)
![historical_cluster_taiwan_tension_timeseries](plots/historical/clusters/historical_cluster_taiwan_tension_timeseries.png)
![historical_cluster_taiwan_vulnerability_timeseries](plots/historical/clusters/historical_cluster_taiwan_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_taiwan_escalation](plots/historical/subscores/historical_subscores_taiwan_escalation.png)
![historical_subscores_taiwan_tension](plots/historical/subscores/historical_subscores_taiwan_tension.png)
![historical_subscores_taiwan_vulnerability](plots/historical/subscores/historical_subscores_taiwan_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_taiwan](plots/fusion/fusion_groups_taiwan.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_taiwan](plots/fusion/fusion_historical_groups_taiwan.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_taiwan](plots/fusion/fusion_historical_total_taiwan.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_taiwan](plots/fusion/v43_country_profile_taiwan.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_taiwan](plots/fusion/v431_peak_attribution_taiwan.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_taiwan](plots/fusion/v432_event_alignment_taiwan.png)

## Poland

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 43.33 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=43.33, max=58.80, min=41.78, Tage hoch/sehr hoch=27, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist erhöht; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 42.04 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=42.04, max=51.95, min=40.27, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist erhöht; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 54.80 (erhöht, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=54.80, max=54.80, min=54.80, Tage hoch/sehr hoch=0, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist erhöht; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 43.33 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 42.04 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 54.80 (erhöht, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 29.38 (Confidence 91.44 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.21), support=narrow (0/7 aktiv), event_stale=False, governance_instability=False, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.79, stale_share=0.00, dynamic_ready=True, dominant_fresh=governance, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 34.24 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 37.66 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 33.99 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 12.17 (Confidence 96.15/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 33.54 (Confidence 88.79/hoch, Coverage 1/1) | sources=narrative_input
- shock: 22.71 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 37.43 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 29.38 (niedrig, ruecklaeufig), Confidence 91.44/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (6.03); governance (5.10), staerkste Aenderung=market_food (-37.59), Interpretation=standard.
- displacement: 34.24 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 37.66 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 33.99 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 12.17 (status=ok, confidence=96.15/hoch, coverage=2/2)
- narrative: 33.54 (status=ok, confidence=88.79/hoch, coverage=1/1)
- shock: 22.71 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 37.43 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: moderat variabel, kontinuierlicher; mean=41.69, range=25.48, volatility=7.42, freshness=fresh_operational.
- Treiberbild: dominant=event, support=narrow, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=54.86, 2026-04=29.38.
- Kritische Peak-Phasen:
- #1 2026-02: 54.86 (erhoeht), driver=market_food, change=event, attr=model_driven_peak, event=weakly_supported, event_match=weak_match, match_conf=0.47, linked_event=Domestic protest and institutional contest, global_share=1.00, country_share=0.00.
- #2 2025-08: 48.19 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.69, linked_event=Regional supply and inflation pressure, global_share=1.00, country_share=0.00.
- #3 2026-03: 42.76 (erhoeht), driver=market_food, change=market_food, attr=model_driven_peak, event=weakly_supported, event_match=weak_match, match_conf=0.49, linked_event=Domestic protest and institutional contest, global_share=1.00, country_share=0.00.
- Mittlere Gruppenbeitraege (Top 3):
- market_food: mean=50.34, share=0.21, availability=1.00.
- event: mean=42.43, share=0.17, availability=1.00.
- shock: mean=50.00, share=0.16, availability=1.00.
- Trajectory: weak_country_specificity, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.59, differentiation=False.
- Event-Alignment: maturity=medium (0.47), credible_ratio=0.33, mean_match_conf=0.55, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Domestic protest and institutional contest | Regional supply and inflation pressure; offene Unsicherheiten=weak_match_share_present.

### 3) Snapshot-Plots (Land)

![poland_escalation_timeseries](plots/snapshot/poland_escalation_timeseries.png)
![poland_tension_timeseries](plots/snapshot/poland_tension_timeseries.png)
![poland_vulnerability_timeseries](plots/snapshot/poland_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_poland_escalation_timeseries](plots/historical/clusters/historical_cluster_poland_escalation_timeseries.png)
![historical_cluster_poland_tension_timeseries](plots/historical/clusters/historical_cluster_poland_tension_timeseries.png)
![historical_cluster_poland_vulnerability_timeseries](plots/historical/clusters/historical_cluster_poland_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_poland_escalation](plots/historical/subscores/historical_subscores_poland_escalation.png)
![historical_subscores_poland_tension](plots/historical/subscores/historical_subscores_poland_tension.png)
![historical_subscores_poland_vulnerability](plots/historical/subscores/historical_subscores_poland_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_poland](plots/fusion/fusion_groups_poland.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_poland](plots/fusion/fusion_historical_groups_poland.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_poland](plots/fusion/fusion_historical_total_poland.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_poland](plots/fusion/v43_country_profile_poland.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_poland](plots/fusion/v431_peak_attribution_poland.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_poland](plots/fusion/v432_event_alignment_poland.png)

## Nigeria

### 1) Current Snapshot (offiziell)

- gesellschaftlich-politische Spannung: 71.38 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=71.38, max=95.11, min=70.68, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gesellschaftlich-politische Spannung ist hoch; Trend stabil; Confidence hoch.
- gewaltsame Eskalation: 67.03 (hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=67.03, max=84.38, min=66.67, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: gewaltsame Eskalation ist hoch; Trend stabil; Confidence hoch.
- strukturelle / systemische Verwundbarkeit: 80.20 (sehr hoch, stabil, hoch) | Δ letzter Run: 0.00 (+0.00%)
  Jahreskontext: aktuell=80.20, max=80.20, min=80.20, Tage hoch/sehr hoch=356, letzter gueltiger Trendpunkt=2026-04-13
  Snapshot-Herkunft: gueltiger Historical-Endpunkt am Run-Datum (2026-04-13).
  Interpretation: strukturelle / systemische Verwundbarkeit ist sehr hoch; Trend stabil; Confidence hoch.

### 2) Historical Rolling Trend (offiziell)

- gesellschaftlich-politische Spannung: letzter gueltiger Punkt 2026-04-13 = 71.38 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- gewaltsame Eskalation: letzter gueltiger Punkt 2026-04-13 = 67.03 (hoch, stabil, hoch), gueltige Punkte im Jahr=352
- strukturelle / systemische Verwundbarkeit: letzter gueltiger Punkt 2026-04-13 = 80.20 (sehr hoch, stabil, hoch), gueltige Punkte im Jahr=352 | methodischer Baseline-Cluster (historische Hilfsquellen aktuell zeitlich konstant)

### 2b) V3.1 Layer/Fusion (zusaetzlich)

- Fusion-Gesamtscore: 50.12 (Confidence 91.76 / hoch), Gruppen 7/7, Bonus=nein.
- V4-Diagnose: dominant=event (share=0.19), support=broad (5/7 aktiv), event_stale=False, governance_instability=True, governance_stale=False, structural_outlier=False.
- Freshness-Diagnose: fresh_support=broad, stale_support=none, fresh_share=0.81, stale_share=0.00, dynamic_ready=True, dominant_fresh=structural, dominant_aging=event, latest_fresh_obs=2026-04-12.
- displacement: 56.41 (Confidence 93.14/hoch, Coverage 1/1) | sources=unhcr
- event: 58.18 (Confidence 88.14/hoch, Coverage 1/1) | sources=gdelt_event
- governance: 55.34 (Confidence 92.89/hoch, Coverage 1/1) | sources=governance_input
- market_food: 20.16 (Confidence 96.33/hoch, Coverage 2/2) | sources=fao_ffpi,fao_fpma
- narrative: 59.31 (Confidence 90.89/hoch, Coverage 1/1) | sources=narrative_input
- shock: 29.88 (Confidence 92.89/hoch, Coverage 1/1) | sources=gdacs
- structural: 90.57 (Confidence 82.02/hoch, Coverage 1/1) | sources=un_comtrade

### 2c) V3.2 Historical Fusion (zusaetzlich)

- Letzter historischer Fusion-Punkt 2026-04: 50.12 (erhoeht, ruecklaeufig), Confidence 91.76/hoch, Coverage=7/7 (1.00), Top-Beitraege=event (9.31); structural (9.06), staerkste Aenderung=market_food (-22.28), Interpretation=standard.
- displacement: 56.41 (status=ok, confidence=93.14/hoch, coverage=1/1)
- event: 58.18 (status=ok, confidence=88.14/hoch, coverage=1/1)
- governance: 55.34 (status=ok, confidence=92.89/hoch, coverage=1/1)
- market_food: 20.16 (status=ok, confidence=96.33/hoch, coverage=2/2)
- narrative: 59.31 (status=ok, confidence=90.89/hoch, coverage=1/1)
- shock: 29.88 (status=ok, confidence=92.89/hoch, coverage=1/1)
- structural: 90.57 (status=ok, confidence=82.02/hoch, coverage=1/1)

### 2d) V4.3 Jahresprofil (zusaetzlich)

- Profil: volatil, kontinuierlicher; mean=63.46, range=28.36, volatility=10.04, freshness=fresh_operational.
- Treiberbild: dominant=event, support=broad, fresh_support=broad, stale_support=none.
- Max/Min: 2026-02=78.48, 2025-10=50.12.
- Kritische Peak-Phasen:
- #1 2025-07: 75.60 (hoch), driver=market_food, change=market_food, attr=model_driven_peak, event=not_event_validated, event_match=direct_match, match_conf=0.83, linked_event=Food price and fiscal stress corridor, global_share=0.79, country_share=0.21.
- #2 2026-02: 78.48 (hoch), driver=market_food, change=event, attr=weakly_supported_peak, event=weakly_supported, event_match=plausible_context_match, match_conf=0.67, linked_event=Election governance insecurity pulse, global_share=0.78, country_share=0.22.
- #3 2026-01: 78.33 (hoch), driver=market_food, change=market_food, attr=weakly_supported_peak, event=weakly_supported, event_match=multi_event_overlap, match_conf=0.68, linked_event=Election governance insecurity pulse, global_share=0.77, country_share=0.23.
- Mittlere Gruppenbeitraege (Top 3):
- event: mean=70.67, share=0.18, availability=1.00.
- governance: mean=65.00, share=0.15, availability=1.00.
- narrative: mean=65.11, share=0.15, availability=1.00.
- Trajectory: broad_multi-layer_stress, country_specific_peak_ratio=0.00, globally_co_moving_peak_ratio=0.00, mean_peak_confidence=0.74, differentiation=False.
- Event-Alignment: maturity=high (0.79), credible_ratio=1.00, mean_match_conf=0.73, global_wave_ratio=0.00, country_specific_ratio=0.00.
- Event-Alignment-Kommentar: Phase ist gemischt (global + laenderspezifisch); Top-Events=Election governance insecurity pulse | Food price and fiscal stress corridor; offene Unsicherheiten=multi_event_overlap_manual_review.

### 3) Snapshot-Plots (Land)

![nigeria_escalation_timeseries](plots/snapshot/nigeria_escalation_timeseries.png)
![nigeria_tension_timeseries](plots/snapshot/nigeria_tension_timeseries.png)
![nigeria_vulnerability_timeseries](plots/snapshot/nigeria_vulnerability_timeseries.png)

### 4) Historical-Cluster-Plots (Land)

![historical_cluster_nigeria_escalation_timeseries](plots/historical/clusters/historical_cluster_nigeria_escalation_timeseries.png)
![historical_cluster_nigeria_tension_timeseries](plots/historical/clusters/historical_cluster_nigeria_tension_timeseries.png)
![historical_cluster_nigeria_vulnerability_timeseries](plots/historical/clusters/historical_cluster_nigeria_vulnerability_timeseries.png)

### 5) Historical-Subscore-Plots (Land)

![historical_subscores_nigeria_escalation](plots/historical/subscores/historical_subscores_nigeria_escalation.png)
![historical_subscores_nigeria_tension](plots/historical/subscores/historical_subscores_nigeria_tension.png)
![historical_subscores_nigeria_vulnerability](plots/historical/subscores/historical_subscores_nigeria_vulnerability.png)

### 6) V3.1 Fusion-Plots (Land)

![fusion_groups_nigeria](plots/fusion/fusion_groups_nigeria.png)

### 7) V3.2 Historical Fusion Group-Plots (Land)

![fusion_historical_groups_nigeria](plots/fusion/fusion_historical_groups_nigeria.png)

### 8) V3.2 Historical Fusion Total-Plots (Land)

![fusion_historical_total_nigeria](plots/fusion/fusion_historical_total_nigeria.png)

### 9) V4.3 Jahresprofil-Plot (Land)

![v43_country_profile_nigeria](plots/fusion/v43_country_profile_nigeria.png)

### 10) V4.3.1 Peak-Attributionsplot (Land)

![v431_peak_attribution_nigeria](plots/fusion/v431_peak_attribution_nigeria.png)

### 11) V4.3.2 Event-Alignment-Plot (Land)

![v432_event_alignment_nigeria](plots/fusion/v432_event_alignment_nigeria.png)
